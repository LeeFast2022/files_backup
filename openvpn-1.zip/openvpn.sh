su
apt update
apt upgrade
apt install -y samba curl wget

apt install -y openvpn easy-rsa
cp -r /usr/share/easy-rsa/ /etc/openvpn/
cd /etc/openvpn/easy-rsa/
#这一句可能要修改，将vars.example复制并重新命名为vars
find / -type f -name "vars.example" | xargs -i cp {} . && mv vars.example vars
#生成证书
./easyrsa init-pki
./easyrsa build-ca
./easyrsa build-ca nopass
#创建服务端证书
./easyrsa gen-req server nopass #提示信息中直接回车
#签约服务端证书
./easyrsa sign server server	#提示信息中，先输入yes，其后输入创建CA时设置的密码
#创建 Diffie-Hellman，时间会有点长，耐心等待
./easyrsa gen-dh
#创建客户端证书
mkdir /etc/openvpn/client
cp -r /usr/share/easy-rsa/ /etc/openvpn/client/easy-rsa
cd /etc/openvpn/client/easy-rsa/
#这一句可能要修改，将vars.example复制并重新命名为vars
find / -type f -name "vars.example" | xargs -i cp {} . && mv vars.example vars
./easyrsa init-pki
./easyrsa gen-req user nopass
#签约客户端证书
./easyrsa import-req /etc/openvpn/client/easy-rsa/3.0.3/pki/reqs/user.req user
./easyrsa sign client user

#整理所需文件
#服务端所需文件
mkdir /etc/openvpn/certs
cd /etc/openvpn/certs/
cp /etc/openvpn/easy-rsa/pki/dh.pem ./
cp /etc/openvpn/easy-rsa/pki/ca.crt ./
cp /etc/openvpn/easy-rsa/pki/issued/server.crt ./
cp /etc/openvpn/easy-rsa/pki/private/server.key ./
#客户端所需文件
mkdir /etc/openvpn/client/user
cp /etc/openvpn/easy-rsa/pki/ca.crt /etc/openvpn/client/user/
cp /etc/openvpn/easy-rsa/pki/issued/user.crt /etc/openvpn/client/user/
cp /etc/openvpn/client/easy-rsa/pki/private/user.key /etc/openvpn/client/user/

#=================================================	server配置文件	=================================================
vim /etc/openvpn/server.conf
#编辑服务器配置文件
#------------------------------------------------------------------------------------------------
#local 192.168.10.100
#定义openvpn监听的IP地址，如果是服务器单网卡的也可以不注明，但是服务器是多网卡的建议注明，如果不注明，会openvpn会监听所有网卡。
	#这个ip地址，就是云服务器的内网ip地址，不能写公网IP，可以写成0.0.0.0
port 6666
#定义openvpn监听的的端口，默认为1194端口。
proto tcp
#定义openvpn使用的协议，默认使用UDP。如果是生产环境的话，建议使用TCP协议。
dev tun
#定义openvpn运行时使用哪一种模式，openvpn有两种运行模式一种是tap模式，一种是tun模式。
	#tap模式也就是桥接模式，通过软件在系统中模拟出一个tap设备，该设备是一个二层设备，同时支持链路层协议。
ca /etc/openvpn/certs/ca.crt
#定义openvpn使用的CA证书文件，该文件通过build-ca命令生成，CA证书主要用于验证客户证书的合法性。
cert /etc/openvpn/certs/server.crt
#定义openvpn服务器端使用的证书文件。
key /etc/openvpn/certs/server.key
#定义openvpn服务器端使用的秘钥文件，该文件必须严格控制其安全性。
dh /etc/openvpn/certs/dh.pem
#定义Diffie hellman文件。

ifconfig-pool-persist /etc/openvpn/ipp.txt
#定义客户端和虚拟ip地址之间的关系。特别是在openvpn重启时,再次连接的客户端将依然被分配和断开之前的IP地址。
#server 10.8.0.2 255.255.255.0
server 10.8.0.0 255.255.255.0
#定义openvpn在使用tun路由模式时，分配给client端分配的IP地址段。
	#原文配置的是10.8.0.2，书上使用了10.8.0.0，更符合分配IP地址段的说法。原文这样设置，应该是不希望客户端IP变化
push "route 192.168.10.0 255.255.255.0"
#向客户端推送的路由信息，假如客户端的IP地址为10.8.0.2，要访问192.168.10.0网段的话，使用这条命令就可以了。又比如：
	#push "route 10.12.0.0 255.255.0.0"
	#push "route 192.168.0.0 255.255.0.0"
	#上面两行的作用为：
	#假设192.168.0.0是VPN服务器所在的局域网的网段，那么添加这条规则后，客户端也能访问与VPN服务器同一网段的其它机器
	#而10.12.0.0是本地网络IP段，这里添加之后客户端就可以访问外网，如百度等。
	#简单的说，这两个路由推送后，客户端对应IP的数据都会发到VPN服务端，然后VPN服务端会将192.168.0.0的数据发网内网，将10.12.0.0的数据发往外网
#route 100.100.0.0 255.255.0.0 #书上有这一句，不知道意义，默认不使用

client-config-dir /etc/openvpn/ccd
#这条命令可以指定客户端IP地址
#使用方法是:
	#在/etc/openvpn/创建ccd目录
	#然后创建在ccd目录下创建以客户端命名的文件。
	#比如要设置客户端user为10.8.0.100这个IP地址，只要在 /etc/openvpn/ccd/user文件中包含如下行即可(文件名取user是为了和客户端证书的common name保持一致):
	#iroute 10.8.0.0 255.255.255.0 (原文中没有这一句，是书上有的，怀疑这样设置后，子网掩码就不是默认的30位了)
	ifconfig-push 10.8.0.100 10.8.0.101    #前面的IP是给客户端的，后面的IP是服务端保留的，分配的地址都是30位掩码

push "redirect-gateway def1 bypass-dhcp"
#此条开启后VPN将代理所有流量，建议不开，此条不开 以下两条也不用开
push "dhcp-option DNS 8.8.8.8"	#向客户端推送DNS信息，如果是云主机应该填写本地DNS
push "dhcp-option DNS 8.8.4.4"
push "dhcp-option DNS 223.5.5.5"
push "dhcp-option DNS 223.6.6.6"

client-to-client #使客户端之间能相互访问，默认设置下客户端间是不能相互访问的。
keepalive 20 120  #定义活动连接保时期限
#comp-lzo   #启用允许数据压缩，客户端配置文件也需要有这项。
#duplicate-cn   #定义openvpn一个证书在同一时刻是否允许多个客户端接入，默认没有启用。
#user openvpn   #运行用户，书上没有设置该参数，所以注释掉
#group openvpn  #运行组，书上没有设置该参数，所以注释掉
persist-key  #通过keepalive检测超时后，重新启动VPN，不重新读取keys，保留第一次使用的keys。
persist-tun  #通过keepalive检测超时后，重新启动VPN，一直保持tun或者tap设备是linkup的。否则网络连接，会先linkdown然后再linkup。
status openvpn-status.log   #把openvpn的一些状态信息写到文件中，比如客户端获得的IP地址。
log-append openvpn.log  #记录日志，每次重新启动openvpn后追加原有的log信息。
verb 1  #设置日志记录冗长级别，日志级别0-9，等级越高，记录越多
mute 20   #重复日志记录限额
#------------------------------------------------------------------------------------------------
#开启内核数据包转发功能
echo 1 >/proc/sys/net/ipv4/ip_forward
head -1 /etc/sysctl.conf
sysctl -p
sysctl -a | grep ip_forward
#配置iptables数据包转发
iptables -t nat -A POSTROUTING -s 10.8.0.0/24 -o eth0 -j MASQUERADE
#iptables -t nat -A POSTROUTING -s 10.8.0.6/30 -o eth0 -d 172.16.206.78 -j MASQUERADE								#书上没有这一条，可能是说明另一种映射方法，所以屏蔽掉
#iptables -t nat -A POSTROUTING -s 192.168.60.204/30 -o eth0 -p tcp --dport 8080 -d 172.16.203.120 -j MASQUERADE	#书上没有这一条，可能是说明另一种映射方法，所以屏蔽掉
	#-s  指定客户端IP ccd文件配置的静态IP
	#-p  指定协议
	#--dport  指定访问目标端口
	#-d  指定访问IP地址
iptables -t nat -L -n --line-number
iptables -t nat -D POSTROUTING 1

#启动VPN
/etc/init.d/openvpn start
#另一种写法如下：
#/usr/local/sbin/openvpn --config /etc/openvpn/server.conf
netstat -anpt | grep openvpn

#==================================================	WINDWOS客户端配置	==================================================
#安装步骤见文档《OpenVpn部署使用easy-rsa-3.0》

#在config文件夹中创建sample.ovpn主配置文件，写入：
client   #指定这是一个客户端，我们将从服务器获取某些配置文件指令
dev tun  #定义openvpn运行时使用哪一种模式，openvpn有两种运行模式一种是tap模式，一种是tun模式。这里和服务端一样
proto tcp   #和服务端配置相同协议
# remote 服务端外网IP  VPN端口
remote  47.97.14.62 6666	#如果有多个VPN服务器，为了实现负载均衡，你可以设置多个remote指令
resolv-retry infinite    #启用该指令，与服务器连接中断后将自动重新连接，这在网络不稳定的情况下(例如：笔记本电脑无线网络)非常有用。
nobind  #大多数客户端不需要绑定本机特定的端口号
persist-key  # 持久化选项可以尽量避免访问在重启时由于用户权限降低而无法访问的某些资源。
persist-tun

ca ca.crt   #服务器生成的三个客户端文件
cert user.crt
key user.key
ns-cert-type server
# 指定通过检查证书的nsCertType字段是否为"server"来验证服务器端证书。
# 这是预防潜在攻击的一种重要措施。
# 为了使用该功能，你需要在生成服务器端证书时，将其中的nsCertType字段设为"server"
# easy-rsa文件夹中的build-key-server脚本文件可以达到该目的。

#comp-lzo
# 在VPN连接中启用压缩。
# 该指令的启用/禁用应该与服务器端保持一致。

verb 3
# 设置日志文件冗余级别(0~9)。
# 0 表示静默运行，只记录致命错误。
# 4 表示合理的常规用法。
# 5 和 6 可以帮助调试连接错误。
# 9 表示极度冗余，输出非常详细的日志信息。

#双击桌面图标OpenVPN GUI，并Connect即可

#==================================================	Linux版客户端配置	==================================================
apt install -y openvpn 
#将下面的三个文件拷贝到客户端/etc/openvpn目录中
	#ca.crt user.crt user.key
#配置文件，参数意义见windows
vim sample.conf
client
dev tun
proto tcp
remote 47.97.14.62 6666
resolv-retry infinite
nobind
persist-key
persist-tun
ca /etc/openvpn/ca.crt
cert /etc/openvpn/user.crt
key /etc/openvpn/user.key
ns-cert-type server
#comp-lzo
verb 3

#启动VPN客户端  openvpn --config /etc/openvpn/client.conf
echo 1 >/proc/sys/net/ipv4/ip_forward
head -1 /etc/sysctl.conf
sysctl -p
sysctl -a | grep ip_forward
openvpn --config /etc/openvpn/sample.conf

#===============================	组网还原	===============================
#Server（云服务器）
内网IP：192.168.10.100
外网IP：47.97.14.62
#配置的虚拟网络参数
	NAT：10.8.0.0
	VPS服务端（云端）：	10.8.0.101
	VPS客户端：			10.8.0.100
	推送DNS：云端的DNS服务器IP
	推送的路由：访问内网的路由，访问外网的路由
	#VPS相当于一块虚拟网卡，从这个网卡出来的数据，搜先被替换IP，其后根据路由信息发送到对应网卡上

#Client（客户端）
	#首先通过服务端的外网IP，连接VPS
	#其后从服务端获取到推送的DNS和路由信息
	#之后对于需要访问的IP，就根据路由信息被自动导游到VPS端口上，VPS相当于一块虚拟的可以访问外网的网卡，让客户端可以访问外网

#问题：对于外网的IP，如何能确保路由都被配置上了
#答案：将所有路由都导入到云服务器，然后从云服务器访问，而不是一部分报文走本地，一部分报文走云端

